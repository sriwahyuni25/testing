<?php

require('vendor/autoload.php');

use BangunDatar\JajarGenjang\JajarGenjang;
use BangunDatar\LayangLayang\Layang;
use BangunDatar\Lingkaran\Lingkaran;
use BangunDatar\PersegiPanjang\PersegiPanjang;
use BangunDatar\Segitiga\Segitiga;
use BangunDatar\Trapesium\Trapesium;
use PHPUnit\Framework\TestCase;

class Test extends TestCase
{
    
    public function testSegitiga()
    {
        
        // instance class yang mau dipakai
        $segitiga = new Segitiga();

        // set attributes value
        $segitiga->setTinggi(6);
        $segitiga->setAlas(3);

        // positive case [Expected Luas = 9 | keliling = 9]
        $this->assertEquals(9, $segitiga->hitungLuas());
        $this->assertEquals(9, $segitiga->hitungKeliling());

        // instance class segitiga
        $segitiga_2 = new Segitiga();

        // kondisi attribute value nya null
        $this->assertSame("Tinggi Tidak Boleh Kosong. Alas Tidak Boleh Kosong. ", $segitiga_2->hitungKeliling());

    }

    public function testPersegiPanjang() {

        // instance
        $persegi = new PersegiPanjang();
        
        // set attributes value
        $persegi->setPanjang(3);
        $persegi->setLebar(6);

        // positive
        $this->assertEquals(18, $persegi->hitungKeliling());
        $this->assertEquals(18, $persegi->hitungLuas());

    }

    public function testLingkaran()
    {
        //instance
        $lingkaran = new Lingkaran();

        //set attributes
        $lingkaran->setjari_jari(5);

        //positive
        $this->assertEquals(31.415926535898, $lingkaran->hitungKeliling());
        $this->assertEquals(78.539816339745, $lingkaran->hitungLuas());
    }

    public function testTrapesium()
    {
        //instance
        $trapesium = new Trapesium();

        //set atributes
        $trapesium->setSisi_a(3);
        $trapesium->setSisi_b(5);
        $trapesium->setSisi_sejajar(7);
        $trapesium->setTinggi(10);

        //positive
        $this->assertEquals(22, $trapesium->hitungKeliling());
        $this->assertEquals(35, $trapesium->hitungLuas());
    }

    public function testLayang()
    {
        //instance
        $layang = new Layang();

        //set attributes
        $layang->setSisi_a(13);
        $layang->setSisi_b(37);
        $layang->setDiagonal_1(40);
        $layang->setDiagonal_2(24);

        //positive TestCase
        $this->assertEquals(100, $layang->hitungKeliling());
        $this->assertEquals(480, $layang->hitungLuas());
    }

    public function testJajarGenjang()
    {
        $JajarGenjang = new JajarGenjang();

        //set atributes
        $JajarGenjang->setAlas(7);
        $JajarGenjang->setSisi_miring(5);
        $JajarGenjang->setTinggi(4);

         //positive TestCase
         $this->assertEquals(24, $JajarGenjang->hitungKeliling());
         $this->assertEquals(28, $JajarGenjang->hitungLuas());
    }
}
