<?php

namespace BangunDatar\Segitiga;

use BangunDatar\BangunDatar;

class Segitiga extends BangunDatar
{
    private $tinggi;

    private $alas;

    function __construct($alas = null, $tinggi = null) {
        $this->alas = $alas;
        $this->tinggi = $tinggi;
    }
    
    public function setTinggi($tinggi = null)
    {
        $this->tinggi = $tinggi;
    }
    
    public function setAlas($alas = null)
    {
        $this->alas = $alas;
    }

    public function validation()
    {
        $message = null;

        if ($this->tinggi == null) {
            $message .= "Tinggi Tidak Boleh Kosong. ";
        }
        
        if ($this->alas == null) {
            $message .= "Alas Tidak Boleh Kosong. ";
        }

        return $message;
    }

    public function hitungLuas()
    {
        $validate = $this->validation();
        
        if ($validate != null) {
            return $validate;
        }

        return 0.5 * $this->alas * $this->tinggi;
    }

    public function hitungKeliling()
    {
        $validate = $this->validation();

        if ($validate != null) {
            return $validate;
        }
        
        return $this->alas * 3;
    }
}
