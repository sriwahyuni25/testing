<?php

//namespace
namespace BangunDatar\Trapesium;

use BangunDatar\BangunDatar;

//class
class Trapesium extends BangunDatar
{
    //atributes
    private $sisi_a;
    private $sisi_b;
    private $sisi_sejajar;
    private $tinggi;

    //constructor
    function __construct($sisi_a = null, $sisi_b = null, $sisi_sejajar = null, $tinggi = null)
    {
        $this->sisi_a = $sisi_a;
        $this->sisi_b = $sisi_b;
        $this->sisi_sejajar = $sisi_sejajar;
        $this->tinggi = $tinggi;
    }

    //buat setter
    public function setSisi_a($sisi_a = null)
    {
        $this->sisi_a = $sisi_a;
    }

    public function setSisi_b($sisi_b = null)
    {
        $this->sisi_b = $sisi_b;
    }

    public function setSisi_sejajar($sisi_sejajar = null)
    {
        $this->sisi_sejajar = $sisi_sejajar;
    }

    public function setTinggi($tinggi = null)
    {
        $this->tinggi = $tinggi;
    }

    //validation
    public function validation()
    {
        $message = null;

        if ($this->sisi_a == null) {
            $message .= "Sisi a tidak boleh kosong.";
        }
        if ($this->sisi_b == null) {
            $message .= "Sisi b tidak boleh kosong.";
        }
        if ($this->sisi_sejajar == null) {
            $message .= "Sisi sejajar tidak boleh kosong.";
        }
        if ($this->tinggi == null) {
            $message .= "Tinggi tidak boleh kosong.";
        }
        return $message;
    }

    //implement parent dari class
    public function hitungLuas()
    {
        $validate = $this->validation();
        if ($validate != null){
            return $validate;
        }
        return ($this->sisi_sejajar * $this->tinggi)/2;
    }
    public function hitungKeliling()
    {
        $validate = $this->validation();
        if ($validate != null){
            return $validate;
        }
        return $this->sisi_a + $this->sisi_b + ($this->sisi_sejajar * 2);
    }
}
