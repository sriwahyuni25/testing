<?php

class Persegi{

    function hitungkeliling($sisi){
        if ($sisi==''){
            return "tidak boleh kosong!";
        }else{
            return $sisi * 4;
        }
  
    }

    function hitungluas($sisi){
        if ($sisi ==''){
            return "tidak boleh kosong!";
        }else{
            return $sisi * $sisi;
        }

    }

}
?>