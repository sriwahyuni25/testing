<?php

//namespace
namespace BangunDatar\JajarGenjang;

use BangunDatar\BangunDatar;

//bikin class
class JajarGenjang extends BangunDatar
{
    // buat attributes
    private $alas;
    private $sisi_miring;
    private $tinggi;

    //buat constructor
    function __construct($alas = null, $sisi_miring = null, $tinggi = null)
    {
        $this->alas = $alas;
        $this->sisi_miring = $sisi_miring;
        $this->tinggi = $tinggi;
    }
    //buat setter
    public function setAlas($alas = null)
    {
        $this->alas = $alas;
    }
    public function setSisi_miring($sisi_miring = null)
    {
        $this->alas = $sisi_miring;
    }
    public function setTinggi($tinggi = null)
    {
        $this->alas = $tinggi;
    }

    //method validation
    public function validation()
    {
        $message = null;

        if ($this->alas == null) {
            $message .= "Alas tidak boleh kosong";
        }
        if ($this->sisi_miring == null) {
            $message .= "Sisi miring tidak boleh kosong";
        }
        if ($this->tinggi == null) {
            $message .= "Tinggi tidak boleh kosong";
        }
        return $message;
    }

    //impement parents dari class
    public function hitungLuas()
    {
        $validate = $this->validation();

        if ($validate != null) {
            return $validate;
        }
        return $this->alas * $this->tinggi;
    }

    public function hitungKeliling()
    {
        $validate = $this->validation();

        if ($validate != null) {
            return $validate;
        }
        return (2 * $this->alas)+(2 * $this->sisi_miring);
    }

}
