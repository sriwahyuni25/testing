<?php

namespace BangunDatar;

abstract class BangunDatar {
    abstract public function hitungLuas();
    abstract public function hitungKeliling();
}