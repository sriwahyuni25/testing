<?php

//namespace
namespace BangunDatar\Lingkaran;

use BangunDatar\BangunDatar;

//membuat class
class Lingkaran extends BangunDatar
{

//attributes
    private $jari_jari;

//nama constructor
function __construct($jari_jari = null) {
    $this->jari_jari = $jari_jari;
}

//setter attributes
public function setjari_jari($jari_jari) {
    $this->jari_jari = $jari_jari;
}

//validation method
public function validation() {
    $message = null;

    if ($this->jari_jari == null) {
        $message .= "Jari-jari tidak boleh kosong.";
    }
    return $message;
}

//implementation method parents dari class method
public function hitungLuas()
{
    $validate = $this->validation();

    if ($validate != null){
        return $validate;
    }
    return pi() * $this->jari_jari * $this->jari_jari;
}
public function hitungKeliling()
{
    $validate = $this->validation();

    if ($validate != null){
        return $validate;
    }
    return  2 * pi() * $this->jari_jari;
}
}
