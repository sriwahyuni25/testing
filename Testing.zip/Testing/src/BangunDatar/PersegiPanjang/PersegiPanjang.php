<?php

// namespace
namespace BangunDatar\PersegiPanjang;

use BangunDatar\BangunDatar;

// bikin class sesuai nama file, lalu extends dengan BangunDatar
class PersegiPanjang extends BangunDatar 
{
    
    // Bikin Attribute sesuai dengan bangun datar nya dengan access modifier private
    private $panjang;

    private $lebar;

    // bikin constructor
    function __construct($panjang = null, $lebar = null){
        $this->panjang = $panjang;
        $this->lebar = $lebar;
    }
    
    // bikin setter buat attributes
    public function setPanjang($panjang = null)
    {
        $this->panjang = $panjang;
    }

    public function setLebar($lebar = null)
    {
        $this->lebar = $lebar;
    }
    
    // Bikin method validation
    public function validation()
    {
        $message = null;

        if ($this->panjang == null) {
            $message .= "Panjang Tidak Boleh kosong.";
        }
        if ($this->lebar == null) {
            $message .= "Lebar Tidak Boleh kosong.";
        }
     return $message;   
    }


    
    // Implementasi method parent dari class
    public function hitungLuas()
    {
        $validate = $this->validation();

        if ($validate != null) {
            return $validate;
        }
        return $this->panjang * $this->lebar;
    }

    public function hitungKeliling()
    {
        $validate = $this->validation();

        if ($validate != null) {
            return $validate;
        }
        return ($this->panjang + $this->lebar)*2;
    }
}


