<?php

//namespace
namespace BangunDatar\LayangLayang;

use BangunDatar\BangunDatar;

//class
class Layang extends BangunDatar
{
    //atributes
    private $sisi_a;
    private $sisi_b;
    private $diagonal_1;
    private $diagonal_2;

    //constructor
    function __construct($sisi_a = null, $sisi_b = null, $diagonal_1 = null, $diagonal_2 = null) {
        $this->sisi_a = $sisi_a;
        $this->sisi_b = $sisi_b;
        $this->diagonal_1 = $diagonal_1;
        $this->diagonal_2 = $diagonal_2;
    }

    //setter attributes
    public function setSisi_a($sisi_a= null)
    {
        $this->sisi_a = $sisi_a;
    }
    public function setSisi_b($sisi_b= null)
    {
        $this->sisi_b = $sisi_b;
    }
    public function setDiagonal_1($diagonal_1= null)
    {
        $this->diagonal_1 = $diagonal_1;
    }
    public function setDiagonal_2($diagonal_2= null)
    {
        $this->diagonal_2 = $diagonal_2;
    }

    //validation function
    public function validation()
    {
        $message = null;

        if ($this->sisi_a === null) {
            $message ="a Tidak boleh kosong.";
        }
        if ($this->sisi_b === null) {
            $message ="b Tidak boleh kosong.";
        }
        if ($this->diagonal_1 === null) {
            $message ="Diagonal 1 tidak boleh kosong.";
        }
        if ($this->diagonal_2 === null) {
            $message ="Diagonal 2 tidak boleh kosong.";
        }
        return $message;
    }

    //implementasi method parent dari class
    public function hitungLuas()
    {
        $validate = $this->validation();

        if ($validate != null) {
            return $validate;
        }
        return 0.5 * $this->diagonal_1 * $this->diagonal_2;
    }
    
    public function hitungKeliling()
    {
        $validate = $this->validation();

        if ($validate != null) {
            return $validate;
        }
        return 2 * ($this->sisi_a + $this->sisi_b);
    }
}
