<?php

    include 'persegi.php';

    $persegi = new persegi();

    $count_success = 0;
    $count_fail = 0;

    //assertion hitung keliling gagal
    $result = $persegi -> hitungkeliling('');
    $expected = "Tidak boleh kosong" ;

    if ($result == $expected){
        echo "hitungkeliling() succes!<br>";
        $count_success++;
    } else {
        echo "hitungkeliling() failed!<br>";
        $count_fail++;
    }

    //assertion hitung keliling betul
    $result = $persegi -> hitungkeliling(2);
    $expected = 8;

    if ($result == $expected){
        echo "hitungkeliling() succes!<br>";
        $count_success++;
    } else {
        echo "hitungkeliling() failed!<br>";
        $count_fail++;
    }


    //assertion hitung luas gagal
    $result = $persegi -> hitungluas('');
    $expected = "Tidak boleh kosong!";

    if ($result == $expected){
        echo "hitungluas() succes!<br>";
        $count_success++;
    } else {
        echo "hitungluas() failed!<br>";
        $count_fail++;
    }
    //assertion hitung luas betul
    $result = $persegi -> hitungluas(2);
    $expected = 4;

    if ($result == $expected){
        echo "hitungluas() succes!<br>";
        $count_success++;
    } else {
        echo "hitungluas() failed!<br>";
        $count_fail++;
    }

    //rekapitulasi
    echo "Test case succes: ", $count_success;
    echo "<br> Test case failed: ", $count_fail;

?>