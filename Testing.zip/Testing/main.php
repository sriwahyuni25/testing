<?php

use BangunDatar\JajarGenjang\JajarGenjang;
use BangunDatar\LayangLayang\Layang;
use BangunDatar\Lingkaran\Lingkaran;
use BangunDatar\PersegiPanjang\PersegiPanjang;
use BangunDatar\Segitiga\Segitiga;
use BangunDatar\Trapesium\Trapesium;

require('vendor/autoload.php');

// Instansiasi class Segitiga
$segitiga = new Segitiga(3, 6);
echo "Segitiga\n";
echo "Keliling = " . $segitiga->hitungKeliling() . "\n";
echo "Luas = " . $segitiga->hitungLuas() . "\n";

// Instansiasi class persegi panjang
$PersegiPanjang = new PersegiPanjang(3,6);
echo "Persegi Panjang\n";
echo "Keliling = " . $PersegiPanjang->hitungKeliling() . "\n";
echo "Luas = " . $PersegiPanjang->hitungLuas(). "\n";

// Instansiasi class lingkaran
$lingkaran = new Lingkaran(5);
echo "Lingkaran\n";
echo "Keliling = " . $lingkaran->hitungKeliling() . "\n";
echo "Luas = " . $lingkaran->hitungLuas(). "\n";

// Instansiasi class trapesium
$trapesium = new Trapesium(3,5,7,10);
echo "Trapesium\n";
echo "Keliling = " . $trapesium->hitungKeliling() . "\n";
echo "Luas = " . $trapesium->hitungLuas(). "\n";

// Instansiasi class layang-layang
$layang = new Layang(13,37,40,24);
echo "Layang\n";
echo "Keliling = " . $layang->hitungKeliling() . "\n";
echo "Luas = " . $layang->hitungLuas(). "\n";

// Instansiasi class jajar genjang
$JajarGenjang = new JajarGenjang(7,5,4);
echo "Jajar Genjang\n";
echo "Keliling = " . $JajarGenjang->hitungKeliling() . "\n";
echo "Luas = " . $JajarGenjang->hitungLuas(). "\n";